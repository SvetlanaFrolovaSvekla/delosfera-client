using System.Globalization;
using System.Text.RegularExpressions;

namespace IsribMigration;

/// <summary>
/// Восстанавливает дату редакции из "грязного" поля name_rus (см. спецификацию, раздел 6).
/// На выборке по всем 747 документам ~94.8% значений успешно парсятся этим алгоритмом.
/// </summary>
public static class EditionDateParser
{
    private static readonly string[] Formats =
    {
        "dd.MM.yyyy", "dd/MM/yyyy", "dd.MM.yy", "dd/MM/yy"
    };

    public static DateTime? TryParse(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return null;

        var cleaned = raw.Trim();
        // убрать хвостовые "г", "г.", одиночную точку после года и т.п.
        cleaned = Regex.Replace(cleaned, @"\s*г\.?\s*$", "", RegexOptions.IgnoreCase);
        cleaned = cleaned.TrimEnd('.', ' ');

        foreach (var fmt in Formats)
        {
            if (DateTime.TryParseExact(cleaned, fmt, CultureInfo.InvariantCulture,
                    DateTimeStyles.None, out var parsed))
                return parsed;
        }

        // последняя попытка — что угодно, что .NET сам распознает как дату
        if (DateTime.TryParse(cleaned, CultureInfo.InvariantCulture, DateTimeStyles.None, out var fallback))
            return fallback;

        return null; // не дата (напр. "38/2013") — вызывающий код должен откатиться на edition_code и залогировать
    }
}
