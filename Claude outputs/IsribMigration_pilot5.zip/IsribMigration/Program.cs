using IsribMigration;
using Microsoft.Extensions.Configuration;
using Minio;

var config = new ConfigurationBuilder()
    .SetBasePath(AppContext.BaseDirectory)
    .AddJsonFile("appsettings.json")
    .Build();

var isribConnStr = config.GetConnectionString("Isrib")!;
var delosferaConnStr = config.GetConnectionString("Delosfera")!;
var pilotCodes = config.GetSection("Migration:PilotDocumentCodes").Get<int[]>()!;
// ⚠ ActualizationPeriod у isrib нет аналога — значение целиком бизнес-решение, вынесено в конфиг,
// а не выведено из данных документа. Проверьте Migration:DefaultActualizationPeriod перед реальной записью.
var defaultActualizationPeriod = ActualizationPeriodMapper.Resolve(config["Migration:DefaultActualizationPeriod"]);

// --write выполняет реальную запись в delosfera. Без флага — только чтение/резолв/печать,
// НИЧЕГО не пишется. Осознанный предохранитель для пилота на 5 документах.
var doWrite = args.Contains("--write");
var useLocalDisk = args.Contains("--local-files"); // проверка пайплайна без MinIO

var reader = new IsribReader(isribConnStr);

IFileUploader fileUploader;
if (!doWrite)
{
    fileUploader = new NotImplementedFileUploader(); // не должен вызываться в dry-run
}
else if (useLocalDisk)
{
    fileUploader = new LocalDiskFileUploader("./migration_local_files");
}
else
{
    var minioSection = config.GetSection("Migration:Minio");
    var minioClient = new MinioClient()
        .WithEndpoint(minioSection["Endpoint"])
        .WithCredentials(minioSection["AccessKey"], minioSection["SecretKey"])
        .WithSSL(minioSection.GetValue<bool>("UseSsl"))
        .Build();
    var uploadedByUserId = config.GetValue<int>("Migration:MigrationUserId");
    fileUploader = new MinioFileUploader(minioClient, minioSection["Bucket"]!, delosferaConnStr, uploadedByUserId);
}

var writer = new DelosferaWriter(delosferaConnStr, fileUploader);

Console.WriteLine(doWrite
    ? $"=== ЗАПИСЬ: пилот на {pilotCodes.Length} документах -> реальная вставка в delosfera ===\n"
    : $"=== DRY RUN: пилот на {pilotCodes.Length} документах — только чтение и резолв, БЕЗ записи в delosfera ===\n");

foreach (var code in pilotCodes)
{
    Console.WriteLine($"--- Документ {code} ---");
    var doc = await reader.ReadAsync(code);

    if (doc.Editions.Count == 0)
    {
        Console.WriteLine("  ⚠ Нет ни одной редакции — документ должен быть ИСКЛЮЧЁН из переноса. Пропускаю.");
        Console.WriteLine();
        continue;
    }

    Console.WriteLine($"  title_ru = {doc.Zagolovok}");
    if (!string.IsNullOrEmpty(doc.ZagolovokKyr))
        Console.WriteLine($"  title_kg = {doc.ZagolovokKyr}");

    Console.WriteLine($"  code = {code}");
    Console.WriteLine($"  adoption_code (nomer) = {doc.Nomer}");
    Console.WriteLine($"  adoption_date (data) = {doc.Data:yyyy-MM-dd}");
    Console.WriteLine($"  effective_date (data_vstup) = {doc.DataVstup:yyyy-MM-dd}");
    Console.WriteLine($"  revision_changed_date (data_izmen) = {doc.DataIzmen:yyyy-MM-dd}");
    if (doc.DataOtmeni.HasValue)
        Console.WriteLine($"  cancel_date = {doc.DataOtmeni:yyyy-MM-dd}, cancel_code = {doc.NomerOtmeni}");

    var status = StatusMapper.ToVndStatus(doc.StatusCode);
    Console.WriteLine($"  status = {(status == StatusMapper.Active ? "Active" : "Archived")} (isrib code = {doc.StatusCode ?? "null"})");

    // --- разработчик / ответственные исполнители: локальный (не-AD) маппинг по названию ---
    var developerId = LocalOrgUnitMapper.ResolveDeveloper(doc.RazrabName);
    Console.WriteLine($"  developer_id (delosfera id) = {developerId}  [{doc.RazrabName}]");

    var executorIds = LocalOrgUnitMapper.ResolveResponsibleExecutors(doc.PodrazdNames);
    Console.WriteLine($"  vnd_responsible_executor: {(executorIds.Count == 0 ? "(пусто)" : string.Join(", ", executorIds))}");

    var typeId = TypeOrganMapper.ResolveTypeId(doc.VidAktaCode);
    var organId = TypeOrganMapper.ResolveOrganId(doc.OrganCode);
    var secrecyLevelId = SecurityLevelMapper.ToSecrecyLevelId(doc.SecurityLevelCode);
    Console.WriteLine($"  type_id = {typeId} ({doc.VidAktaName})");
    Console.WriteLine($"  organ_id = {organId} ({doc.OrganName})");
    Console.WriteLine($"  secrecy_level_id = {secrecyLevelId}");

    var orderedEditions = doc.Editions
        .OrderBy(e => e.ParsedDate ?? DateTime.MinValue)
        .ThenBy(e => e.EditionCode)
        .ToList();

    Console.WriteLine($"  Редакции ({orderedEditions.Count}):");
    for (int i = 0; i < orderedEditions.Count; i++)
    {
        var e = orderedEditions[i];
        var isCurrent = i == orderedEditions.Count - 1;
        var dateNote = e.ParsedDate.HasValue ? e.ParsedDate.Value.ToString("yyyy-MM-dd") : $"⚠ не распознана ('{e.NameRaw}'), сортировка по edition_code";
        Console.WriteLine($"    #{i + 1}{(isCurrent ? " [ТЕКУЩАЯ -> current_redaction_id]" : "")}: edition_code={e.EditionCode}, дата={dateNote}, " +
                           $"text_rus={(e.TextRus?.Length ?? 0)} байт ({e.TextRusType}), картинок={e.ImagesByLang.Count}");
    }

    if (doc.Attachments.Count > 0)
        Console.WriteLine($"  Вложения ({doc.Attachments.Count}) -> vnd_redaction_attachment на редакцию #{orderedEditions.Count}: " +
                           string.Join(", ", doc.Attachments.Select(a => a.FileName)));

    if (doWrite)
    {
        var keywordIds = new List<int>();  // vnd_keyword маппинг классификатора id=4 -> keyword_id ещё не построен, оставляем пустым
        var rubricIds = new List<int>();   // vnd_rubric маппинг классификатора id=5 -> rubric_id ещё не построен, оставляем пустым

        var documentId = await writer.MigrateDocumentAsync(
            doc, typeId, organId, secrecyLevelId, status,
            developerId, developerIsPlaceholder: false, executorIds, keywordIds, rubricIds,
            defaultActualizationPeriod);

        Console.WriteLine($"  ✅ Записано в delosfera: vnd_document.id = {documentId}");
    }

    Console.WriteLine();
}

Console.WriteLine(doWrite ? "Готово." : "Dry run завершён. Для реальной записи: dotnet run -- --write (или --write --local-files для проверки без MinIO).");
