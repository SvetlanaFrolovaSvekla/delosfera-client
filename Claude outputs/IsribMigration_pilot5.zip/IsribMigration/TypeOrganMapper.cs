namespace IsribMigration;

/// <summary>
/// vid_akta (classificator_id=1) -> dictionary_type_vnd.id
/// organ (classificator_id=2) -> dictionary_approval_body.id
/// Оба справочника маленькие, полностью собраны вручную — отдельный JSON не нужен.
/// Ключ — КОД элемента классификатора в isrib (не название: у "Матрица"/"Правление" по два кода на одно значение).
/// </summary>
public static class TypeOrganMapper
{
    private static readonly Dictionary<string, int> VidAktaToTypeId = new()
    {
        ["10"] = 11,  // Политика
        ["11"] = 6,   // Концепция
        ["12"] = 17,  // Регламент
        ["20"] = 12,  // Положение
        ["22"] = 1,   // Базовые условия кредитного продукта
        ["30"] = 18,  // Руководство
        ["300"] = 20, // Устав
        ["301"] = 8,  // Матрица
        ["45aea9e8-53d9-4dc1-9852-1db221e85790"] = 8, // Матрица (второй код, то же значение)
        ["31"] = 5,   // Кодекс
        ["41"] = 3,   // Должностная инструкция
        ["50"] = 14,  // Правила
        ["60"] = 13,  // Порядок
        ["70"] = 16,  // Процедура
        ["80"] = 9,   // Методика
        ["8dbd9634-301b-4c3b-b347-7cd8079e6da4"] = 7, // Лимиты
        ["90"] = 10,  // План
        ["91"] = 15,  // Программа
        ["d5142611-3670-43b2-a440-ff58f4d0fbea"] = 2, // Договор
        ["40"] = 4,   // Инструкция (ВАЖНО: НЕ дублирующий id=21 в dictionary_type_vnd — тот был ошибочной записью)
        ["100"] = 21, // Приказ — добавлено в dictionary_type_vnd
        ["200"] = 22, // Распоряжение — добавлено
        ["16"] = 23,  // Соглашение — добавлено
        ["17"] = 24,  // Расписка — добавлено
        ["b34d95c1-2045-47cf-92bc-2045e7913231"] = 25, // Тариф — добавлено
        ["000000000000013"] = 26, // Организационная структура — добавлено
        // код "" (пусто) = "Система" — служебный корень классификатора isrib, не настоящее значение,
        // документов с таким значением на выборке не встречалось, но на всякий случай не резолвится.
    };

    private static readonly Dictionary<string, int> OrganToOrganId = new()
    {
        ["10"] = 2,     // Общее собрание акционеров
        ["100"] = 1,    // Комитет по управлению активами и пассивами
        ["20"] = 7,     // Совет директоров
        ["200"] = 8,    // Тарифный комитет
        ["30"] = 3,     // Правление
        ["30.10"] = 3,  // Правление (второй код, то же значение)
        ["30.20"] = 5,  // Председатель Правления
        ["30.40"] = 4,  // Заместитель Председателя Правления
        ["30.50"] = 6,  // член Правления
        // ["300"] = ???,  // Кредитный комитет — ЖДЁМ решение + id после INSERT в dictionary_approval_body
    };

    public static int ResolveTypeId(string? vidAktaCode)
    {
        if (vidAktaCode != null && VidAktaToTypeId.TryGetValue(vidAktaCode, out var id)) return id;
        throw new InvalidOperationException(
            $"Код вида документа '{vidAktaCode}' не найден в маппинге TypeOrganMapper.VidAktaToTypeId — проверьте, не 'Система' ли это (служебный корень).");
    }

    public static int ResolveOrganId(string? organCode)
    {
        if (organCode != null && OrganToOrganId.TryGetValue(organCode, out var id)) return id;
        throw new InvalidOperationException(
            $"Код органа '{organCode}' не найден в маппинге TypeOrganMapper.OrganToOrganId — возможно, это 'Кредитный комитет' (код 300), для него ещё нет id в dictionary_approval_body.");
    }
}

/// <summary>Гриф секретности: коды и названия в isrib и delosfera совпадают 1:1, пересчёт не нужен.</summary>
public static class SecurityLevelMapper
{
    public static int ToSecrecyLevelId(int isribSecurityLevelCode) => isribSecurityLevelCode;
}
