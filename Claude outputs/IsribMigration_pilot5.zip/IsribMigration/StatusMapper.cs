namespace IsribMigration;

/// <summary>
/// isrib status (property 40, classificator 6) имеет только два реальных значения на 747 документов:
/// "10" = Действует, "020" = Не действует. 3 документа без значения (9028, 10101) -> Active по умолчанию,
/// документ 9873 (пустой, без редакций) должен быть исключён из переноса ДО вызова этого маппера.
/// </summary>
public static class StatusMapper
{
    // Значения перечисления VndStatus (delosfera-server/Modules/Documents/VND/Models/VndStatus.cs)
    public const int Active = 0;
    public const int Archived = 4;

    public static int ToVndStatus(string? isribStatusCode) => isribStatusCode switch
    {
        "10" => Active,
        "020" => Archived,
        null => Active,   // 9028, 10101 — статус не проставлен, документ содержательный -> Active по умолчанию
        _ => throw new InvalidOperationException(
            $"Неизвестный код статуса isrib '{isribStatusCode}' — на выборке 747 документов встречались только '10' и '020', это новый случай, нужно решение.")
    };
}
