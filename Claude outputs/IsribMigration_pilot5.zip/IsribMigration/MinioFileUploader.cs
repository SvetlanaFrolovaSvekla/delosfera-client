using System.Security.Cryptography;
using Minio;
using Minio.DataModel.Args;
using Npgsql;

namespace IsribMigration;

/// <summary>
/// Реальная реализация IFileUploader для этого отдельного консольного скрипта миграции.
/// Пишет объект в MinIO и создаёт строку в file_attachments напрямую через Npgsql —
/// НЕ через EF DbContext delosfera-server (у нас его тут нет и я не могу проверить его классы).
///
/// ⚠ ПРОВЕРЬТЕ перед первым запуском с --write:
///   1. Название бакета и креды в Migration:Minio (appsettings.json).
///   2. Точные имена столбцов file_attachments ниже — я предположил их по стандартной схеме
///      (original_file_name, content_type, size_bytes, storage_key, bucket, hash, uploaded_by_user_id,
///      created_at) — сверьте с реальной DDL вашей БД и поправьте INSERT при необходимости.
///   3. uploaded_by_user_id — тут нет "текущего пользователя" (это батч-скрипт, не веб-запрос);
///      задаётся через Migration:MigrationUserId в конфиге — подставьте id технической/сервисной учётки.
/// </summary>
public class MinioFileUploader : IFileUploader
{
    private readonly IMinioClient _minio;
    private readonly string _bucket;
    private readonly string _delosferaConnStr;
    private readonly int _uploadedByUserId;

    public MinioFileUploader(IMinioClient minio, string bucket, string delosferaConnStr, int uploadedByUserId)
    {
        _minio = minio;
        _bucket = bucket;
        _delosferaConnStr = delosferaConnStr;
        _uploadedByUserId = uploadedByUserId;
    }

    public async Task<int> UploadAsync(byte[] content, string originalFileName, string contentType)
    {
        var hash = Convert.ToHexStringLower(SHA256.HashData(content));
        var objectName = $"{Guid.NewGuid()}/{originalFileName}";

        await using (var stream = new MemoryStream(content))
        {
            await _minio.PutObjectAsync(new PutObjectArgs()
                .WithBucket(_bucket)
                .WithObject(objectName)
                .WithStreamData(stream)
                .WithObjectSize(content.LongLength)
                .WithContentType(contentType));
        }

        await using var conn = new NpgsqlConnection(_delosferaConnStr);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO file_attachments
                (original_file_name, content_type, size_bytes, storage_key, bucket, hash, uploaded_by_user_id, created_at)
            VALUES
                (@name, @contentType, @size, @storageKey, @bucket, @hash, @uploadedBy, now())
            RETURNING id;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("name", originalFileName);
        cmd.Parameters.AddWithValue("contentType", contentType);
        cmd.Parameters.AddWithValue("size", content.LongLength);
        cmd.Parameters.AddWithValue("storageKey", objectName);
        cmd.Parameters.AddWithValue("bucket", _bucket);
        cmd.Parameters.AddWithValue("hash", hash);
        cmd.Parameters.AddWithValue("uploadedBy", _uploadedByUserId);

        return (int)(await cmd.ExecuteScalarAsync())!;
    }
}

/// <summary>
/// Тестовый uploader для сухого прогона реальной записи БЕЗ MinIO — кладёт файлы на диск
/// и всё равно пишет строку в file_attachments (storage_key = локальный путь). Полезно, чтобы
/// проверить весь пайплайн (включая docx-конвертацию и вставки в delosfera) до подключения MinIO.
/// НЕ использовать для настоящих 747 документов — только для локальной проверки пилота.
/// </summary>
public class LocalDiskFileUploader : IFileUploader
{
    private readonly string _outputDir;

    public LocalDiskFileUploader(string outputDir)
    {
        _outputDir = outputDir;
        Directory.CreateDirectory(outputDir);
    }

    public Task<int> UploadAsync(byte[] content, string originalFileName, string contentType)
    {
        var path = Path.Combine(_outputDir, $"{Guid.NewGuid()}_{originalFileName}");
        File.WriteAllBytes(path, content);
        Console.WriteLine($"    [LocalDiskFileUploader] сохранено: {path} ({content.Length} байт)");
        // возвращаем детерминированный "id" на основе счётчика файлов в папке — только для теста
        return Task.FromResult(Directory.GetFiles(_outputDir).Length);
    }
}
