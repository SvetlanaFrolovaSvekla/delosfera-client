namespace IsribMigration;

/// <summary>
/// Замена OrgUnitMapping.cs + DelosferaOrgUnitResolver.cs для ПИЛОТА на 5 документах в текущей
/// локальной среде разработки: там dictionary_organization_unit — ручной 11-строчный справочник
/// (id 1-11), БЕЗ AD/LDAP-синхронизации и БЕЗ external_id вообще. Поэтому вместо резолва
/// external_id -> внутренний id живым запросом к базе (как в "боевом" сценарии на 747 документах,
/// см. DelosferaOrgUnitResolver.cs) здесь просто прямой словарь:
///   название подразделения из isrib (razrab/podrazd) -> id в текущем local dictionary_organization_unit.
///
/// Если встретится название, которого нет в словаре — бросаем понятную ошибку с точным именем
/// (для developer_id, т.к. поле NOT NULL) или тихо пропускаем с предупреждением в консоль
/// (для vnd_responsible_executor — M2M, пустой список валиден).
/// </summary>
public static class LocalOrgUnitMapper
{
    /// <summary>
    /// 3 служебных ("маркерных") значения isrib в полях podrazd/razrab, которые не являются
    /// настоящими подразделениями (обсуждено и согласовано с пользователем — пропускаем без
    /// специальной обработки, поле остаётся пустым/null).
    /// </summary>
    public static readonly HashSet<string> MarkerNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "все сотрудники Банка",
        "Структурные подразделения",
        "Филиал",
    };

    public static bool IsMarker(string? name) => name != null && MarkerNames.Contains(name);

    /// <summary>
    /// id в текущем локальном dictionary_organization_unit (см. DevLocalOrgSeeder больше НЕ
    /// используется — это реальные id из уже накатанной локальной сид-миграции).
    /// ⚠ Если у следующего пилотного документа встретится название, которого здесь нет —
    /// добавьте строку сюда (id смотрите в dictionary_organization_unit локальной БД).
    /// </summary>
    private static readonly Dictionary<string, int> NameToId = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Совет директоров"] = 1,
        ["Правление"] = 2,
        ["Управление комплаенс контроля (УКК)"] = 3,
        ["Управление продаж малого и среднего бизнеса (УП МСБ)"] = 4,
        ["Управление кредитования"] = 5,
        ["Управление по работе с виртуальными активами (УРВА)"] = 6,
        ["Операционное управление"] = 7,
        ["Управление информационных технологий (УИТ)"] = 8,
    };

    /// <summary>developer_id обязателен (NOT NULL) в vnd_document. IsribReader уже отфильтровал
    /// маркерные razrab-строки и выбрал первое настоящее имя — сюда должно прийти реальное название.</summary>
    public static int ResolveDeveloper(string? razrabName)
    {
        if (razrabName == null)
            throw new InvalidOperationException(
                "У документа нет ни одного НЕ-маркерного значения razrab (property 64) — developer_id (NOT NULL) заполнить нечем.");
        if (NameToId.TryGetValue(razrabName, out var id)) return id;
        throw new InvalidOperationException(
            $"Подразделение-разработчик '{razrabName}' отсутствует в LocalOrgUnitMapper.NameToId — " +
            "посмотрите id в dictionary_organization_unit и добавьте строку в словарь.");
    }

    /// <summary>vnd_responsible_executor (M2M) — пустой список валиден: и маркерные значения,
    /// и названия, которых пока нет в словаре, тихо пропускаются (перенос документа не блокируется).</summary>
    public static List<int> ResolveResponsibleExecutors(IEnumerable<string> podrazdNames)
    {
        var result = new List<int>();
        foreach (var name in podrazdNames)
        {
            if (IsMarker(name)) continue;
            if (NameToId.TryGetValue(name, out var id))
                result.Add(id);
            else
                Console.WriteLine($"    ⚠ podrazd '{name}' не найдено в LocalOrgUnitMapper — пропущено (добавьте вручную при необходимости).");
        }
        return result.Distinct().ToList();
    }
}
