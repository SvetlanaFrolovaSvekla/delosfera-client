namespace IsribMigration.Models;

/// <summary>Основные данные документа ВНД из isrib (таблица document + property_value_*).</summary>
public class IsribVndDocument
{
    public int DocumentCode { get; set; }
    public int SecurityLevelCode { get; set; }          // document.security_level_code (база, не property)

    // classificator-свойства: и код, и название элемента (name_rus из classificator_item) —
    // название нужно для сопоставления по org_unit_mapping_final.json, код — для логов/отладки.
    public string? VidAktaCode { get; set; }             // 36 vid_akta -> type_id
    public string? VidAktaName { get; set; }              // ⚠️ маппинг vid_akta -> dictionary_type_vnd ЕЩЁ НЕ ПОСТРОЕН
    public string? OrganCode { get; set; }                // 37 organ -> organ_id
    public string? OrganName { get; set; }                // ⚠️ маппинг organ -> dictionary_approval_body ЕЩЁ НЕ ПОСТРОЕН
    public string? StatusCode { get; set; }               // 40 status -> Active/Archived (см. StatusMapper)
    public string? RazrabCode { get; set; }               // 64 razrab -> developer_id
    public string? RazrabName { get; set; }               // ключ для org_unit_mapping_final.json -> razrab_developer
    public List<string> PodrazdCodes { get; set; } = new(); // 63 podrazd -> vnd_responsible_executor
    public List<string> PodrazdNames { get; set; } = new(); // ключи для org_unit_mapping_final.json -> podrazd_responsible
    public List<string> KluchSlovCodes { get; set; } = new(); // 53 -> vnd_keyword
    public List<string> KlassifikatorCodes { get; set; } = new(); // 54 -> vnd_rubric

    // строковые/датные свойства
    // РЕШЕНО (раздел 8, п.1, проверено на пилоте 269/7010/7008/9028/10101): property 56 (nazvanie)
    // пустое на всех проверенных документах, реальный заголовок — в property 55 (zagolovok).
    public string? Zagolovok { get; set; }                 // 55 zagolovok -> title_ru
    public string? ZagolovokKyr { get; set; }               // тот же property, string_kyr
    public string? Nomer { get; set; }                     // 39 nomer -> adoption_code
    public DateTime? Data { get; set; }                    // 38 data -> adoption_date
    public DateTime? DataVstup { get; set; }                // 43 data_vstup -> effective_date
    public DateTime? DataIzmen { get; set; }                // 62 data_izmen -> revision_changed_date (часто NULL)
    public DateTime? DataOtmeni { get; set; }               // 65 data_otmeni -> cancel_date
    public string? NomerOtmeni { get; set; }               // 71 nomer_otmeni -> cancel_code

    public List<IsribEdition> Editions { get; set; } = new();
    public List<IsribAttachment> Attachments { get; set; } = new(); // 61 vlogeniya, не привязаны к редакции
}

/// <summary>Одна редакция документа (property_value_edition, property_id=57).</summary>
public class IsribEdition
{
    public int EditionCode { get; set; }                  // НЕ используется для сортировки/номера — см. NameRaw
    public string? NameRaw { get; set; }                   // name_rus — на практике дата редакции в ~95% случаев
    public DateTime? ParsedDate { get; set; }               // результат парсинга NameRaw по алгоритму из спецификации

    public byte[]? TextRus { get; set; }
    public string? TextRusType { get; set; }               // ожидается ".htm"
    public byte[]? TextKyr { get; set; }
    public string? TextKyrType { get; set; }
    public byte[]? TextEng { get; set; }
    public string? TextEngType { get; set; }

    /// <summary>Картинки из property_value_edition_file для этой редакции, ключ = имя файла как в &lt;img src&gt;.</summary>
    public Dictionary<string, byte[]> ImagesByLang { get; set; } = new(); // фактически нужно разделять по lang, см. IsribReader
}

/// <summary>Вложение из property_value_attachment (property_id=61) — общее на документ, не на редакцию.</summary>
public class IsribAttachment
{
    public string Code { get; set; } = "";
    public string? Description { get; set; }
    public string FileName { get; set; } = "";
    public byte[] Data { get; set; } = Array.Empty<byte>();
}
