using Npgsql;

namespace IsribMigration;

/// <summary>
/// Загрузка файла в MinIO и создание записи file_attachments.
/// ЗАГЛУШКА — как только пришлёте реальный FileStorageService из delosfera-server,
/// эта реализация меняется на использование того же кода (тот же бакет/тот же способ генерации storage_key).
/// </summary>
public interface IFileUploader
{
    Task<int> UploadAsync(byte[] content, string originalFileName, string contentType);
}

public class NotImplementedFileUploader : IFileUploader
{
    public Task<int> UploadAsync(byte[] content, string originalFileName, string contentType) =>
        throw new NotImplementedException(
            "Загрузка в MinIO ещё не подключена — нужен реальный FileStorageService из delosfera-server " +
            "(как генерируется storage_key, в какой бакет пишется).");
}

public class DelosferaWriter
{
    private readonly string _connectionString;
    private readonly IFileUploader _fileUploader;

    public DelosferaWriter(string connectionString, IFileUploader fileUploader)
    {
        _connectionString = connectionString;
        _fileUploader = fileUploader;
    }

    /// <summary>
    /// Полный перенос одного документа: vnd_document -> все vnd_redaction -> current_redaction_id ->
    /// keywords/rubrics/responsible_executors -> (если нужно) комментарий "Требует доработки".
    /// Возвращает id созданного vnd_document.
    /// </summary>
    public async Task<int> MigrateDocumentAsync(
        Models.IsribVndDocument doc,
        int typeId, int organId, int secrecyLevelId, int status,
        int developerId, bool developerIsPlaceholder,
        List<int> responsibleExecutorIds, List<int> keywordIds, List<int> rubricIds,
        int defaultActualizationPeriod)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();
        await using var tx = await conn.BeginTransactionAsync();

        try
        {
            // 1. vnd_document, current_redaction_id пока NULL — редакций ещё нет
            var documentId = await InsertDocumentAsync(conn, doc, typeId, organId, secrecyLevelId, status, developerId, defaultActualizationPeriod);

            // 2. все редакции, отсортированные по хронологии (см. EditionDateParser)
            var orderedEditions = doc.Editions
                .OrderBy(e => e.ParsedDate ?? DateTime.MinValue)
                .ThenBy(e => e.EditionCode)
                .ToList();

            var redactionIds = new List<int>();
            for (int i = 0; i < orderedEditions.Count; i++)
            {
                var edition = orderedEditions[i];
                var isLast = i == orderedEditions.Count - 1;

                // текст редакции: HTML -> DOCX (картинки из edition.ImagesByLang встраиваются внутри конвертера)
                byte[] docxBytes;
                try
                {
                    docxBytes = HtmlToDocxConverter.Convert(edition.TextRus, edition.ImagesByLang);
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException(
                        $"Документ {doc.DocumentCode}, редакция #{i + 1} (edition_code={edition.EditionCode}, ru): " +
                        $"не удалось сконвертировать HTML в DOCX — {ex.Message}", ex);
                }
                var docFileRuId = await _fileUploader.UploadAsync(docxBytes, $"{doc.DocumentCode}_ред{i + 1}_ru.docx",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document");

                int? docFileKgId = null;
                if (edition.TextKyr is { Length: > 0 })
                {
                    byte[] docxKg;
                    try
                    {
                        docxKg = HtmlToDocxConverter.Convert(edition.TextKyr, edition.ImagesByLang);
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidOperationException(
                            $"Документ {doc.DocumentCode}, редакция #{i + 1} (edition_code={edition.EditionCode}, kg): " +
                            $"не удалось сконвертировать HTML в DOCX — {ex.Message}", ex);
                    }
                    docFileKgId = await _fileUploader.UploadAsync(docxKg, $"{doc.DocumentCode}_ред{i + 1}_kg.docx",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
                }

                var description = (isLast && developerIsPlaceholder) ? "Требует доработки" : null;

                // Реквизиты (adoption/effective date) в isrib хранятся ОДИН раз на документ, а не на
                // редакцию — истории "какие были реквизиты у Р1/Р2" isrib не даёт. Заполняем их
                // только для последней (текущей) редакции, где они реально совпадают с doc.Data/
                // doc.Nomer/doc.DataVstup; для более старых редакций оставляем null (поля nullable) —
                // это не потеря данных, а честное отражение того, что isrib этого не хранил.
                var redactionCode = $"{doc.DocumentCode}-Р{i + 1}";
                var redactionId = await InsertRedactionAsync(
                    conn, documentId, i + 1, redactionCode, doc.Zagolovok, doc.ZagolovokKyr,
                    docFileRuId, docFileKgId, typeId, organId, secrecyLevelId, developerId, description,
                    defaultActualizationPeriod,
                    isLast ? doc.Data : null, isLast ? doc.Nomer : null, isLast ? doc.DataVstup : null);
                redactionIds.Add(redactionId);

                if (isLast)
                {
                    // вложения (ТИД, лист согласования и т.п.) — все на текущую (последнюю) редакцию
                    foreach (var att in doc.Attachments)
                    {
                        var attFileId = await _fileUploader.UploadAsync(att.Data, att.FileName, GuessContentType(att.FileName));
                        await InsertRedactionAttachmentAsync(conn, redactionId, attFileId);
                    }
                }
            }

            // 3. current_redaction_id = последняя по хронологии редакция
            await SetCurrentRedactionAsync(conn, documentId, redactionIds[^1]);

            // 4. связи M2M
            await LinkManyToManyAsync(conn, "vnd_responsible_executor", "vnd_id", "organization_unit_id", documentId, responsibleExecutorIds);
            await LinkManyToManyAsync(conn, "vnd_keyword", "vnd_id", "keyword_id", documentId, keywordIds);
            await LinkManyToManyAsync(conn, "vnd_rubric", "vnd_id", "rubric_id", documentId, rubricIds);

            await tx.CommitAsync();
            return documentId;
        }
        catch
        {
            await tx.RollbackAsync();
            throw;
        }
    }

    private static async Task<int> InsertDocumentAsync(NpgsqlConnection conn, Models.IsribVndDocument doc,
        int typeId, int organId, int secrecyLevelId, int status, int developerId, int defaultActualizationPeriod)
    {
        const string sql = @"
            INSERT INTO vnd_document
                (code, title_ru, title_kg, status, type_id, developer_id, organ_id,
                 adoption_date, adoption_code, effective_date, revision_changed_date,
                 cancel_date, cancel_code, secrecy_level_id, last_actualization_had_changes,
                 period, actualization_requires_approval, actualization_shift_next_period,
                 actualization_planned_no_changes, actualization_performed, archived_date,
                 created_at, updated_at)
            VALUES
                (@code, @titleRu, @titleKg, @status, @typeId, @developerId, @organId,
                 @adoptionDate, @adoptionCode, @effectiveDate, @revisionChangedDate,
                 @cancelDate, @cancelCode, @secrecyLevelId, @lastActualizationHadChanges,
                 @period, @actualizationRequiresApproval, @actualizationShiftNextPeriod,
                 @actualizationPlannedNoChanges, @actualizationPerformed, @archivedDate,
                 now(), now())
            RETURNING id;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("code", doc.DocumentCode.ToString());
        cmd.Parameters.AddWithValue("titleRu", (object?)doc.Zagolovok ?? DBNull.Value);
        cmd.Parameters.AddWithValue("titleKg", (object?)doc.ZagolovokKyr ?? DBNull.Value);
        cmd.Parameters.AddWithValue("status", status);
        cmd.Parameters.AddWithValue("typeId", typeId);
        cmd.Parameters.AddWithValue("developerId", developerId);
        cmd.Parameters.AddWithValue("organId", organId);
        cmd.Parameters.AddWithValue("adoptionDate", (object?)doc.Data ?? DBNull.Value);
        cmd.Parameters.AddWithValue("adoptionCode", (object?)doc.Nomer ?? DBNull.Value);
        cmd.Parameters.AddWithValue("effectiveDate", (object?)doc.DataVstup ?? DBNull.Value);
        cmd.Parameters.AddWithValue("revisionChangedDate", (object?)doc.DataIzmen ?? DBNull.Value);
        cmd.Parameters.AddWithValue("cancelDate", (object?)doc.DataOtmeni ?? DBNull.Value);
        cmd.Parameters.AddWithValue("cancelCode", (object?)doc.NomerOtmeni ?? DBNull.Value);
        cmd.Parameters.AddWithValue("secrecyLevelId", secrecyLevelId);
        // last_actualization_had_changes / actualization_* : относятся к workflow цикла актуализации
        // в delosfera, которого у перенесённых legacy-документов никогда не было и не идёт сейчас —
        // false для всех четырёх безопасно и семантически верно независимо от результата п.4 ниже.
        cmd.Parameters.AddWithValue("lastActualizationHadChanges", false);
        cmd.Parameters.AddWithValue("actualizationRequiresApproval", false);
        cmd.Parameters.AddWithValue("actualizationShiftNextPeriod", false);
        cmd.Parameters.AddWithValue("actualizationPlannedNoChanges", false);
        cmd.Parameters.AddWithValue("actualizationPerformed", false);
        // period: у isrib НЕТ аналога периодичности плановой актуализации — значение подставляется
        // из Migration:DefaultActualizationPeriod (appsettings.json), а не выводится из данных.
        // ⚠ ЭТО ОТКРЫТЫЙ БИЗНЕС-ВОПРОС, не техническая деталь: перед прогоном на всех 747 документах
        // нужно решение, какая периодичность должна быть у перенесённых ВНД (возможно, разная по
        // типу документа/органу утверждения, а не одна на всё). Сейчас — единое значение из конфига.
        cmd.Parameters.AddWithValue("period", defaultActualizationPeriod);
        // archived_date: используется в VndDocument.DaysInArchive. У isrib нет отдельного поля
        // "дата архивации" — берём data_otmeni (дата отмены), это и есть момент, когда документ
        // перестал действовать и попал в архив по факту.
        cmd.Parameters.AddWithValue("archivedDate",
            status == StatusMapper.Archived && doc.DataOtmeni.HasValue ? doc.DataOtmeni.Value : (object)DBNull.Value);

        return (int)(await cmd.ExecuteScalarAsync())!;
    }

    private static async Task<int> InsertRedactionAsync(NpgsqlConnection conn, int documentId, int number,
        string code, string? titleRu, string? titleKg, int docFileRuId, int? docFileKgId,
        int typeId, int organId, int secrecyLevelId, int developerId, string? description,
        int period, DateTime? adoptionDate, string? adoptionCode, DateTime? effectiveDate)
    {
        const string sql = @"
            INSERT INTO vnd_redaction
                (vnd_id, number, code, title_ru, title_kg, doc_file_ru_id, doc_file_kg_id, type_id, organ_id,
                 secrecy_level_id, developer_id, description, approval_status, period,
                 adoption_date, adoption_code, effective_date,
                 requires_approval, created_at, updated_at)
            VALUES
                (@vndId, @number, @code, @titleRu, @titleKg, @docFileRuId, @docFileKgId, @typeId, @organId,
                 @secrecyLevelId, @developerId, @description, @approvalStatus, @period,
                 @adoptionDate, @adoptionCode, @effectiveDate,
                 false, now(), now())
            RETURNING id;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("vndId", documentId);
        cmd.Parameters.AddWithValue("number", number);
        cmd.Parameters.AddWithValue("code", code);
        // title_ru на редакции по модели должен отражать заголовок НА МОМЕНТ этой редакции — но
        // isrib хранит заголовок только один раз на документ, истории смены заголовка по редакциям
        // нет. Подставляем текущий Zagolovok во все редакции (включая прошлые) — это известное
        // упрощение, а не потерянные данные: у isrib просто нет источника для точного значения
        // по каждой старой редакции.
        cmd.Parameters.AddWithValue("titleRu", (object?)titleRu ?? DBNull.Value);
        cmd.Parameters.AddWithValue("titleKg", (object?)titleKg ?? DBNull.Value);
        cmd.Parameters.AddWithValue("docFileRuId", docFileRuId);
        cmd.Parameters.AddWithValue("docFileKgId", (object?)docFileKgId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("typeId", typeId);
        cmd.Parameters.AddWithValue("organId", organId);
        cmd.Parameters.AddWithValue("secrecyLevelId", secrecyLevelId);
        cmd.Parameters.AddWithValue("developerId", developerId);
        cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
        cmd.Parameters.AddWithValue("approvalStatus", 2); // RedactionApprovalStatus.Approved — все переносимые уже утверждены
        // ⚠ "2" для RedactionApprovalStatus не сверено с реальным enum (файл не присылали, в отличие
        // от ActualizationPeriod/VndStatus) — проверьте перед массовым прогоном на 747 документах.
        cmd.Parameters.AddWithValue("period", period);
        cmd.Parameters.AddWithValue("adoptionDate", (object?)adoptionDate ?? DBNull.Value);
        cmd.Parameters.AddWithValue("adoptionCode", (object?)adoptionCode ?? DBNull.Value);
        cmd.Parameters.AddWithValue("effectiveDate", (object?)effectiveDate ?? DBNull.Value);

        return (int)(await cmd.ExecuteScalarAsync())!;
    }

    private static async Task InsertRedactionAttachmentAsync(NpgsqlConnection conn, int redactionId, int fileAttachmentId)
    {
        const string sql = "INSERT INTO vnd_redaction_attachment (vnd_redaction_id, file_attachment_id) VALUES (@r, @f);";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("r", redactionId);
        cmd.Parameters.AddWithValue("f", fileAttachmentId);
        await cmd.ExecuteNonQueryAsync();
    }

    private static async Task SetCurrentRedactionAsync(NpgsqlConnection conn, int documentId, int redactionId)
    {
        const string sql = "UPDATE vnd_document SET current_redaction_id = @r WHERE id = @d;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("r", redactionId);
        cmd.Parameters.AddWithValue("d", documentId);
        await cmd.ExecuteNonQueryAsync();
    }

    private static async Task LinkManyToManyAsync(NpgsqlConnection conn, string table, string docColumn, string otherColumn,
        int documentId, List<int> otherIds)
    {
        foreach (var otherId in otherIds.Distinct())
        {
            var sql = $"INSERT INTO {table} ({docColumn}, {otherColumn}) VALUES (@d, @o) ON CONFLICT DO NOTHING;";
            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("d", documentId);
            cmd.Parameters.AddWithValue("o", otherId);
            await cmd.ExecuteNonQueryAsync();
        }
    }

    private static string GuessContentType(string fileName) => Path.GetExtension(fileName).ToLowerInvariant() switch
    {
        ".pdf" => "application/pdf",
        ".doc" => "application/msword",
        ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".xls" => "application/vnd.ms-excel",
        ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".jpg" or ".jpeg" => "image/jpeg",
        ".png" => "image/png",
        ".tif" or ".tiff" => "image/tiff",
        _ => "application/octet-stream",
    };
}
