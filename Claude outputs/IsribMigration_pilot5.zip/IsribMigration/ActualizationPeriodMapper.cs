namespace IsribMigration;

/// <summary>
/// Значения перечисления ActualizationPeriod
/// (delosfera-server/Modules/Documents/VND/DTO/Request/ActualizationPeriod.cs) — подтверждены
/// явно (в файле есть закомментированная версия с проставленными числами, совпадающая с
/// порядком объявления): Quarterly=0, HalfYear=1, Annual=2, Biennial=3, Triennial=4, Custom=5.
///
/// У isrib нет аналога периодичности плановой актуализации — какое значение проставить
/// перенесённым документам, это ОТКРЫТЫЙ БИЗНЕС-ВОПРОС, не техническая деталь. Значение задаётся
/// строкой в Migration:DefaultActualizationPeriod (appsettings.json) именно чтобы решение было
/// видно и легко менялось, а не было зашито в код.
/// </summary>
public static class ActualizationPeriodMapper
{
    private static readonly Dictionary<string, int> NameToValue = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Quarterly"] = 0,
        ["HalfYear"] = 1,
        ["Annual"] = 2,
        ["Biennial"] = 3,
        ["Triennial"] = 4,
        ["Custom"] = 5,
    };

    public static int Resolve(string? name)
    {
        if (name != null && NameToValue.TryGetValue(name, out var value)) return value;
        throw new InvalidOperationException(
            $"Migration:DefaultActualizationPeriod = '{name}' не распознано. Ожидались: {string.Join(", ", NameToValue.Keys)}.");
    }
}
