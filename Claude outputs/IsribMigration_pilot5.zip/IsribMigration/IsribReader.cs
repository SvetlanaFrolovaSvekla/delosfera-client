using Dapper;
using IsribMigration.Models;
using Microsoft.Data.SqlClient;

namespace IsribMigration;

/// <summary>
/// Читает один документ ВНД из isrib (SQL Server) и собирает IsribVndDocument.
/// Схема подтверждена по факту (INFORMATION_SCHEMA.COLUMNS) на локальной базе isrib:
///   document(document_code, class_id, security_level_code, folder_id)
///   property_value_classificator(document_code, property_id, sequence, code nvarchar, class_id, classificator_id, checked)
///   classificator_item(classificator_id, code nvarchar, parent_code, name_rus, name_kyr, tag, sort_rank)
///   property_value_string(document_code, property_id, sequence, string_rus, string_kyr, class_id)
///   property_value_date(document_code, property_id, sequence, date, class_id)
///   property_value_edition(id, document_code, property_id, edition_code, text_rus/text_rus_type/name_rus,
///                           text_kyr/text_kyr_type/name_kyr, text_eng/text_eng_type/name_eng)
///   property_value_edition_file(document_code, property_id, edition_code, lang, name, data)
///   property_value_attachment(document_code, property_id, code, description, file_name, data)
///
/// ВАЖНО: classificator_item.code и property_value_classificator.code — ОБА nvarchar (не int).
/// Join — по паре (classificator_id, code), не по отдельному item_id (такой колонки нет).
///
/// Иерархические классификаторы (напр. "organ") денормализованы: property_value_classificator
/// хранит одновременно И выбранный код, И все коды-предки по цепочке parent_code как отдельные
/// строки для того же документа+свойства. Нужен самый ГЛУБОКИЙ (специфичный) код — см.
/// ReadDeepestClassificatorAsync.
/// </summary>
public class IsribReader
{
    // property_id-ы свойств документа (см. migration_spec_vnd.md)
    private const int PropVidAkta = 36;
    private const int ClassifVidAkta = 1;
    private const int PropOrgan = 37;
    private const int ClassifOrgan = 2;
    private const int PropStatus = 40;
    private const int ClassifStatus = 6;
    private const int PropRazrab = 64;
    private const int PropPodrazd = 63;
    private const int PropKluchSlov = 53;
    private const int PropKlassifikator = 54;
    private const int PropZagolovok = 55;
    private const int PropNomer = 39;
    private const int PropNomerOtmeni = 71;
    private const int PropData = 38;
    private const int PropDataVstup = 43;
    private const int PropDataIzmen = 62;
    private const int PropDataOtmeni = 65;
    private const int PropEdition = 57;
    private const int PropAttachment = 61;

    private readonly string _connectionString;

    public IsribReader(string connectionString) => _connectionString = connectionString;

    public async Task<IsribVndDocument> ReadAsync(int documentCode)
    {
        await using var conn = new SqlConnection(_connectionString);
        await conn.OpenAsync();

        var doc = new IsribVndDocument { DocumentCode = documentCode };

        // --- базовые поля документа ---
        var baseRow = await conn.QuerySingleOrDefaultAsync(
            "SELECT security_level_code FROM document WHERE document_code = @code",
            new { code = documentCode });
        if (baseRow == null)
            throw new InvalidOperationException($"Документ {documentCode} не найден в таблице document.");
        doc.SecurityLevelCode = baseRow.security_level_code == null ? 0 : (int)baseRow.security_level_code;

        // --- classificator-свойства ---
        var (vidAktaCode, vidAktaName) = await ReadDeepestClassificatorAsync(conn, documentCode, PropVidAkta, ClassifVidAkta);
        doc.VidAktaCode = vidAktaCode;
        doc.VidAktaName = vidAktaName;

        var (organCode, organName) = await ReadDeepestClassificatorAsync(conn, documentCode, PropOrgan, ClassifOrgan);
        doc.OrganCode = organCode;
        doc.OrganName = organName;

        var (statusCode, _) = await ReadDeepestClassificatorAsync(conn, documentCode, PropStatus, ClassifStatus);
        doc.StatusCode = statusCode;

        // razrab (64): по факту на пилотных документах бывает несколько строк — одна реальная,
        // другая служебная-маркерная ("Структурные подразделения" и т.п.). Берём первое
        // НЕ-маркерное имя (см. LocalOrgUnitMapper.MarkerNames — согласовано с пользователем).
        var razrabRows = await ReadClassificatorRowsAsync(conn, documentCode, PropRazrab, classificatorId: null);
        var razrabPick = razrabRows.FirstOrDefault(r => !LocalOrgUnitMapper.IsMarker(r.Name));
        doc.RazrabCode = razrabPick?.Code;
        doc.RazrabName = razrabPick?.Name;

        // podrazd (63): список; маркерные значения ("все сотрудники Банка"/"Филиал" и т.п.)
        // сохраняем как есть — фильтрация делается позже, в LocalOrgUnitMapper.ResolveResponsibleExecutors,
        // чтобы вся "оргсемантика" (что считать маркером) была в одном месте.
        var podrazdRows = await ReadClassificatorRowsAsync(conn, documentCode, PropPodrazd, classificatorId: null);
        foreach (var r in podrazdRows)
        {
            if (r.Code != null) doc.PodrazdCodes.Add(r.Code);
            if (r.Name != null) doc.PodrazdNames.Add(r.Name);
        }

        doc.KluchSlovCodes = (await ReadClassificatorRowsAsync(conn, documentCode, PropKluchSlov, null))
            .Where(r => r.Code != null).Select(r => r.Code!).ToList();
        doc.KlassifikatorCodes = (await ReadClassificatorRowsAsync(conn, documentCode, PropKlassifikator, null))
            .Where(r => r.Code != null).Select(r => r.Code!).ToList();

        // --- строковые свойства ---
        var zagolovokRow = await conn.QueryFirstOrDefaultAsync(
            "SELECT string_rus, string_kyr FROM property_value_string WHERE document_code=@code AND property_id=@p ORDER BY sequence",
            new { code = documentCode, p = PropZagolovok });
        doc.Zagolovok = zagolovokRow?.string_rus;
        doc.ZagolovokKyr = zagolovokRow?.string_kyr;

        doc.Nomer = await conn.QueryFirstOrDefaultAsync<string?>(
            "SELECT string_rus FROM property_value_string WHERE document_code=@code AND property_id=@p ORDER BY sequence",
            new { code = documentCode, p = PropNomer });

        doc.NomerOtmeni = await conn.QueryFirstOrDefaultAsync<string?>(
            "SELECT string_rus FROM property_value_string WHERE document_code=@code AND property_id=@p ORDER BY sequence",
            new { code = documentCode, p = PropNomerOtmeni });

        // --- датные свойства ---
        doc.Data = await ReadDateAsync(conn, documentCode, PropData);
        doc.DataVstup = await ReadDateAsync(conn, documentCode, PropDataVstup);
        doc.DataIzmen = await ReadDateAsync(conn, documentCode, PropDataIzmen);
        doc.DataOtmeni = await ReadDateAsync(conn, documentCode, PropDataOtmeni);

        // --- редакции ---
        var editionRows = await conn.QueryAsync(
            @"SELECT edition_code, name_rus, text_rus, text_rus_type, text_kyr, text_kyr_type, text_eng, text_eng_type
              FROM property_value_edition
              WHERE document_code=@code AND property_id=@p
              ORDER BY edition_code",
            new { code = documentCode, p = PropEdition });

        foreach (var row in editionRows)
        {
            var edition = new IsribEdition
            {
                EditionCode = (int)row.edition_code,
                NameRaw = row.name_rus,
                TextRus = row.text_rus,
                TextRusType = row.text_rus_type,
                TextKyr = row.text_kyr,
                TextKyrType = row.text_kyr_type,
                TextEng = row.text_eng,
                TextEngType = row.text_eng_type,
            };
            edition.ParsedDate = EditionDateParser.TryParse(edition.NameRaw);
            if (edition.ParsedDate == null)
                Console.WriteLine($"    ⚠ Документ {documentCode}, edition_code={edition.EditionCode}: дата не распознана из '{edition.NameRaw}', сортировка по edition_code.");

            // картинки для этой редакции — ключ по имени файла, как встречается в <img src="..."> HTML
            var fileRows = await conn.QueryAsync(
                "SELECT name, data FROM property_value_edition_file WHERE document_code=@code AND property_id=@p AND edition_code=@ec",
                new { code = documentCode, p = PropEdition, ec = edition.EditionCode });
            foreach (var f in fileRows)
            {
                string? name = f.name;
                byte[]? data = f.data;
                if (name != null && data != null) edition.ImagesByLang[name] = data;
            }

            doc.Editions.Add(edition);
        }

        // --- вложения ---
        var attRows = await conn.QueryAsync(
            "SELECT code, description, file_name, data FROM property_value_attachment WHERE document_code=@code AND property_id=@p",
            new { code = documentCode, p = PropAttachment });
        foreach (var a in attRows)
        {
            doc.Attachments.Add(new IsribAttachment
            {
                Code = a.code ?? "",
                Description = a.description,
                FileName = a.file_name ?? "",
                Data = a.data ?? Array.Empty<byte>(),
            });
        }

        return doc;
    }

    /// <summary>
    /// Возвращает самый глубокий (специфичный) код классификатора для документа+свойства:
    /// код, который сам ни у одной другой строки этого же документа+свойства не встречается
    /// как parent_code. Для неиерархических классификаторов (одна строка) просто её и возвращает.
    /// </summary>
    private static async Task<(string? Code, string? Name)> ReadDeepestClassificatorAsync(
        SqlConnection conn, int documentCode, int propertyId, int classificatorId)
    {
        var rows = await ReadClassificatorRowsAsync(conn, documentCode, propertyId, classificatorId);
        if (rows.Count == 0) return (null, null);
        if (rows.Count == 1) return (rows[0].Code, rows[0].Name);

        var parentCodes = rows.Select(r => r.ParentCode).Where(p => p != null).ToHashSet();
        var deepest = rows.FirstOrDefault(r => r.Code != null && !parentCodes.Contains(r.Code));
        return deepest != null ? (deepest.Code, deepest.Name) : (rows[0].Code, rows[0].Name);
    }

    private static async Task<List<ClassificatorRow>> ReadClassificatorRowsAsync(
        SqlConnection conn, int documentCode, int propertyId, int? classificatorId)
    {
        var sql = @"
            SELECT pvc.code AS Code, ci.name_rus AS Name, ci.parent_code AS ParentCode
            FROM property_value_classificator pvc
            LEFT JOIN classificator_item ci
                ON ci.classificator_id = pvc.classificator_id AND ci.code = pvc.code
            WHERE pvc.document_code = @code AND pvc.property_id = @p" +
            (classificatorId.HasValue ? " AND pvc.classificator_id = @cid" : "") +
            " ORDER BY pvc.sequence";

        var rows = await conn.QueryAsync<ClassificatorRow>(sql,
            new { code = documentCode, p = propertyId, cid = classificatorId });
        return rows.ToList();
    }

    private static async Task<DateTime?> ReadDateAsync(SqlConnection conn, int documentCode, int propertyId)
    {
        return await conn.QueryFirstOrDefaultAsync<DateTime?>(
            "SELECT date FROM property_value_date WHERE document_code=@code AND property_id=@p ORDER BY sequence",
            new { code = documentCode, p = propertyId });
    }

    private class ClassificatorRow
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? ParentCode { get; set; }
    }
}
