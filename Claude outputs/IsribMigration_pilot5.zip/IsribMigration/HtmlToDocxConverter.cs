using System.Text;
using System.Text.RegularExpressions;
using AngleSharp.Html.Parser;
using AngleSharpElement = AngleSharp.Dom.IElement;
using AngleSharpNodeType = AngleSharp.Dom.NodeType;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using HtmlToOpenXml;

namespace IsribMigration;

/// <summary>
/// Конвертация HTML-текста редакции (property_value_edition.text_rus/kyr/eng) в DOCX.
/// Проверено на пилоте: документ 269 (4 редакции) прошёл без проблем. Документ 7010 упал —
/// см. SanitizeEmptyElements: HtmlToOpenXml 3.1.0 содержит непофикшенный баг (issue onizet/
/// html2openxml#161 на GitHub, автор закрыл без исправления) — на ЛЮБОМ полностью пустом
/// блочном элементе (без единого дочернего узла, даже текстового) внутри библиотеки вызывается
/// LINQ .First() без проверки на пустоту и падает "Sequence contains no elements". У нас
/// сработало на пустом заголовке (h1-h6), но по тому же паттерну может сработать на пустом
/// <li>, <td> и т.п. — баг общий для класса "пустой блочный элемент", не специфичен для заголовков.
/// </summary>
public static class HtmlToDocxConverter
{
    /// <summary>Void-элементы HTML5 — у них по спецификации нет и не может быть дочерних узлов,
    /// это нормально и не триггерит баг библиотеки (баг именно про случайно опустевшие БЛОЧНЫЕ
    /// контейнеры типа "было отредактировано и весь текст удалили, тег остался"). Добавлять в них
    /// текст-заглушку нельзя и не нужно.</summary>
    private static readonly HashSet<string> VoidOrSkipTags = new(StringComparer.OrdinalIgnoreCase)
    {
        "area", "base", "br", "col", "embed", "hr", "img", "input", "link",
        "meta", "param", "source", "track", "wbr", "script", "style",
    };

    public static byte[] Convert(byte[]? htmlBytes, Dictionary<string, byte[]> imagesByFileName)
    {
        if (htmlBytes == null || htmlBytes.Length == 0)
            throw new InvalidOperationException("Пустой HTML — нечего конвертировать (проверьте, что редакция реально содержит текст).");

        var html = DecodeHtml(htmlBytes);
        html = SanitizeEmptyElements(html);
        html = InlineImagesAsDataUri(html, imagesByFileName);

        using var stream = new MemoryStream();
        using (var package = WordprocessingDocument.Create(stream, WordprocessingDocumentType.Document))
        {
            var mainPart = package.AddMainDocumentPart();
            mainPart.Document = new Document(new Body());

            var converter = new HtmlConverter(mainPart);
            var paragraphs = converter.Parse(html);
            mainPart.Document.Body!.Append(paragraphs);
            mainPart.Document.Save();
        }
        return stream.ToArray();
    }

    /// <summary>
    /// Обходит баг onizet/html2openxml#161: находит абсолютно пустые (или эффективно пустые —
    /// содержащие только пробельный текст, в т.ч. &amp;nbsp;) блочные элементы и вставляет внутрь
    /// них zero-width space (U+200B), чтобы у элемента появился хоть один непробельный child-узел.
    /// Визуально в итоговом DOCX это незаметно, а библиотека больше не натыкается на пустую
    /// коллекцию рансов. Void-элементы (br/img/hr и т.п.) и script/style не трогаем — им children
    /// не положены по спецификации, и баг не про них.
    /// </summary>
    internal static string SanitizeEmptyElements(string html)
    {
        var parser = new HtmlParser();
        var document = parser.ParseDocument(html);

        // ВАЖНО (найдено на документе 7010, редакция 2040): проверка "!el.HasChildNodes" ловит
        // только элементы БЕЗ единого узла внутри. Но встречаются элементы вида "<h1>\r\n</h1>" —
        // с одним текстовым узлом, состоящим только из пробелов/переводов строк (типичный артефакт
        // pretty-printed HTML из более старых редакций/другого экспортёра). HasChildNodes у них true,
        // санитайзер их пропускал — а HtmlToOpenXml при разборе тримит такой пробельный текст,
        // получает ноль "рансов" внутри блока и падает на том же .First() из issue #161, просто
        // на другом варианте "пустоты". Поэтому теперь считаем элемент пустым, если среди ЕГО
        // непосредственных детей нет ни одного дочернего элемента и ни одного непробельного
        // текстового узла (комментарии и чисто пробельный текст в расчёт не идут).
        bool IsEffectivelyEmpty(AngleSharpElement el)
        {
            if (VoidOrSkipTags.Contains(el.TagName)) return false;
            foreach (var child in el.ChildNodes)
            {
                if (child.NodeType == AngleSharpNodeType.Element) return false; // напр. <img>/<br>/<span> внутри — не пусто
                if (child.NodeType == AngleSharpNodeType.Text && !string.IsNullOrWhiteSpace(child.TextContent)) return false;
            }
            return true;
        }

        var emptyElements = document.All
            .Where(IsEffectivelyEmpty)
            .ToList(); // .ToList() — материализуем ДО модификации дерева, иначе живой LINQ over DOM собьётся

        // ⚠ НЕ неразрывный пробел (U+00A0)! Несмотря на название "неразрывный", NBSP относится
        // к юникод-категории Zs (Space Separator) — .NET's char.IsWhiteSpace('\u00A0') == true,
        // и string.IsNullOrWhiteSpace тоже считает его пробелом. На документе 7010 (редакция 2040)
        // это вскрылось на практике: там пустой <h1> изначально СОДЕРЖАЛ "&nbsp;" (типичный
        // артефакт WYSIWYG-редактора — весь текст стёрли, nbsp оставили, чтобы не схлопывалась
        // высота строки). Наш детектор пустоты (ниже) корректно считает такой узел "пустым" — но
        // если чинить его вставкой ТОГО ЖЕ nbsp, HtmlToOpenXml при разборе тримит его как обычный
        // пробел тем же алгоритмом и падает на том самом .First() — ничего не меняется.
        // Zero-width space (U+200B) — юникод-категория Cf (Format), НЕ пробел ни для .NET, ни для
        // любого стандартного \s-паттерна, при этом визуально невидим в итоговом DOCX так же, как
        // и nbsp. Правильная замена.
        foreach (var el in emptyElements)
            el.TextContent = "\u200B";

        return document.DocumentElement.OuterHtml;
    }

    /// <summary>
    /// В isrib &lt;meta charset="unicode"&gt; — судя по всему, поле фактически хранится как UTF-16 (nvarchar-стиль).
    /// Пробуем Unicode (UTF-16LE), при ошибке — UTF-8 как запасной вариант.
    /// </summary>
    private static string DecodeHtml(byte[] htmlBytes)
    {
        try
        {
            var text = Encoding.Unicode.GetString(htmlBytes);
            if (text.Contains("<html", StringComparison.OrdinalIgnoreCase)) return text;
        }
        catch { /* пробуем следующий вариант */ }

        return Encoding.UTF8.GetString(htmlBytes);
    }

    private static string InlineImagesAsDataUri(string html, Dictionary<string, byte[]> imagesByFileName)
    {
        if (imagesByFileName.Count == 0) return html;

        return Regex.Replace(html, @"src=[""']([^""']+)[""']", match =>
        {
            var fileName = match.Groups[1].Value;
            var shortName = Path.GetFileName(fileName); // на случай, если в src путь, а не голое имя
            if (!imagesByFileName.TryGetValue(shortName, out var bytes) &&
                !imagesByFileName.TryGetValue(fileName, out bytes))
                return match.Value; // картинки нет — оставляем как есть, будет "битая" ссылка в итоговом docx

            var mime = Path.GetExtension(shortName).ToLowerInvariant() switch
            {
                ".png" => "image/png",
                ".gif" => "image/gif",
                _ => "image/jpeg",
            };
            return $"src=\"data:{mime};base64,{System.Convert.ToBase64String(bytes)}\"";
        }, RegexOptions.IgnoreCase);
    }
}
